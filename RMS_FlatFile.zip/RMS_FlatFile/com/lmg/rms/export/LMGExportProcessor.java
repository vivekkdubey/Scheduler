/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright (c) 2011 LandMark Group.    All Rights Reserved.
 *
 *  Rev 1.0   Mar 18 2011 Ashutosh.Tripathi 
 *  This interface will be the starting point of file export process.  
 *  Interface will be responsible for embedding the business logic. 
 *  There will be an implementation of process method in the implementation class
 *  of this interface which will internally make use of interfaces like
 *  LMGExportDataProcessor, LMGExportDataFormatter and LMGExportFileWriter. 
 *  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
package com.lmg.rms.export;

/**
 * This interface is the starting point for the Export Processing.
 * 
 * @author Ashutosh Mani
 *
 */
public interface LMGExportProcessor {
	void process();
}
