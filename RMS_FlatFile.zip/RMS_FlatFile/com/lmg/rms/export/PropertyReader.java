/**
 * Class Name: PropertyReader
 *
 * @Purpose:This class cater to functionality of reading property files for DIMP and RTLog file download and upload.
 * This Class is Created by Infogain India Pvt Ltd.(http://www.infogain.com/)
 * @Author:Ashwini.Kumar
 * @Version: 1.0
 * @Date:Jan 28, 2011
 * Last Modified On:
 * Known Issues:
 *
 *Copyright (c) 2010 Lifestyle India Pvt Ltd.    All Rights Reserved.
 */

package com.lmg.rms.export;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * This class cater to functionality of reading property files 
 * for DIMP and RTLog file download and upload.
 * 
 * @author Ashutosh Mani
 *
 */
public class PropertyReader
{

	private static Logger log = Logger.getLogger(PropertyReader.class);

	public void updateProperties(String key, String value, String fileName)
	{
		Properties prop = new Properties();
		try
		{
			prop.load(new FileInputStream(fileName));
			prop.setProperty(key, value);
			prop.store(new FileOutputStream(new File(fileName)), null);
		}
		catch (IOException e)
		{
			log.info(e.getMessage());
		}
	}
}