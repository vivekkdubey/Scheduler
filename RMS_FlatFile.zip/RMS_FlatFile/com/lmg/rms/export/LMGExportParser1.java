/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class LMGExportParser1 {

	/**
	 * @param args
	 */
	public static LMGExportConfig createLMGExportXml(ResultSet resultSet) throws Exception {
		
		LMGExportConfig config = new LMGExportConfig();
		
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory
				.newDocumentBuilder();
		Document doc = documentBuilder.newDocument();
		int colCount = resultSet.getMetaData().getColumnCount();

		Element root = doc.createElement("export");
		doc.appendChild(root);

		Element header = doc.createElement("header");
		root.appendChild(header);
		
		// @ TODO set the header list into config object
		
		Element table = doc.createElement("table");
		root.appendChild(table);

		Text columnName = null;
		Text columnNumber = null;
		List<String> headerList = new ArrayList<String>();
		for (int i = 1; i < colCount + 1; i++) {

			Element column = doc.createElement("column");
			table.appendChild(column);

			Element filecolumn = doc.createElement("filecolumn");
			column.appendChild(filecolumn);
			columnNumber = doc.createTextNode("Column " + i);
			filecolumn.appendChild(columnNumber);

			Element datacolumn = doc.createElement("columnname");
			column.appendChild(datacolumn);
			String colName = resultSet.getMetaData().getColumnName(i);
			columnName = doc.createTextNode(colName);
			datacolumn.appendChild(columnName);

			Element elements = doc.createElement("elements");
			header.appendChild(elements);
			Text newelement = doc.createTextNode("Fileheader" + i + "_"
					+ colName);
			elements.appendChild(newelement);
			headerList.add(newelement.getNodeValue());
		}
		//LMGExportFactory.setFlatFileHeaderList(headerList);

		TransformerFactory factory = TransformerFactory.newInstance();
		Transformer transformer = factory.newTransformer();

		transformer.setOutputProperty(OutputKeys.INDENT, "yes");

		StringWriter sw = new StringWriter();
		StreamResult result = new StreamResult(sw);
		DOMSource source = new DOMSource(doc);
		transformer.transform(source, result);
		String xmlString = sw.toString();

		String filePath = "C:/WSpace/";
		String fileName = "LMGExport.xml";

		File file = new File(filePath + fileName);
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		bw.write(xmlString);
		bw.flush();
		bw.close();
		
		// @ TODO set the table list into config object
		
		return config;
	}
}
