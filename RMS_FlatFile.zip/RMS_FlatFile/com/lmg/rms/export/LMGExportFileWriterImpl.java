/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import oracle.sql.TIMESTAMP;

import org.apache.log4j.Logger;

/**
 * This class is a file writer class used to create flat file.
 * 
 * @author Ashutosh Mani
 *
 */
public class LMGExportFileWriterImpl implements LMGExportFileWriter {

	private static Logger log = Logger.getLogger(LMGExportFileWriterImpl.class);

	/**
	 * Used to create flat file with .dat.
	 */
	public void createFlatFile(ResultSet resultSet, Writer out) {
		List<String> headerList = new ArrayList<String>();
		int rowcount = 0;
		FileWriter fw;
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream(
					LMGImportExportUtilityIfc.LMGImportExport_properties));
			DateFormat DF = new SimpleDateFormat("ddMMyyyy_HHmmss");
			String timestmp = DF.format(new Date());
			String filePath = prop
					.getProperty(LMGImportExportUtilityIfc.LMGImportExport_SRC_DIR);
			String fileName = ("pos2rms_12001_" + timestmp + ".dat");
			if (resultSet.isBeforeFirst() ) {
				File file = new File(filePath + fileName);
				fw = new FileWriter(file, true);
				out = new BufferedWriter(fw);
				boolean isHeader = true;
				try {
					if (isHeader == true)
						headerList = LMGExportConfig.getFileHeader();
					for (int header = 0; header < headerList.size(); header++) {
						out.write("<"+headerList.get(header)+">");
						if (header != headerList.size() - 1) {
							out.write(",");
						}
						isHeader = false;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				int colCount = resultSet.getMetaData().getColumnCount();
				out.append("\n");
				while (resultSet.next()) {
					for (int i = 0; i <= colCount; i++) {
						if (i > 0) {
							Object value = resultSet.getObject(i);
							if (value == null || resultSet.wasNull()) {
								out.append("");
								if (i != colCount) {
									out.append(",");
								}
							} else {
								if(value instanceof TIMESTAMP)
								{
									out.append(((TIMESTAMP) value).dateValue().toString());
								}
								else
								{
										value=value.toString().replace(Character.toString ((char) 10), Character.toString ((char) 44));
										value=value.toString().replace(Character.toString ((char) 13), Character.toString ((char) 44));
										value=value.toString().replace(Character.toString ((char) 44), Character.toString ((char) 32));

									out.append(value.toString());
								}
								if (i != colCount) {
									out.append(",");
								}
							}
						}
					} // end of column. loop to next column.
					out.append("\n");
					rowcount++;
				}// End of current row. loop to next row.

		}
		} catch (IOException e) {
			log.info(e.getMessage());
		} catch (SQLException e) {
			log.info(e.getMessage());
		} finally {
			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (SQLException sqle) {
					log.info("Unable to close ResultSet.");
				}
			}
			if (out != null) {
				try {
					out.close();
				} catch (IOException ioe) {
					log.info("Unable to close File Writer.");
				}
			}

		}
	}
}
