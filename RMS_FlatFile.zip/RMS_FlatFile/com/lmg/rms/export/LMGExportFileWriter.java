/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright (c) 2011 LandMark Group.    All Rights Reserved.
 *
 *  Rev 1.0   Mar 18 2011 Ashutosh.Tripathi 
 *  This interface will be having method declaration of creating the flat file. 
 *  In the implementation of this method we will be having business code for writing the flat file
 *  to a specific location. The flat file will contain the data fetched 
 *  from the ORCO database in the specified format.
 *	The Flat file will later be consumed by DMS.
 *  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
package com.lmg.rms.export;

import java.io.Writer;
import java.sql.ResultSet;

/**
 *  This is a interface  class for creating flat file.
 *  
 * @author ashutosh.tripathi
 * 
 */
public interface LMGExportFileWriter {
	void createFlatFile(ResultSet resultSet, Writer out);
}
