/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This class is used to create query for select statement
 * and for update statement.
 * 
 * @author Ashutosh Mani
 *
 */
public class LMGExportParser {
	
	private static Logger log = Logger.getLogger(LMGExportParser.class);

	static File file;
	static DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
	static LMGQueryMapper mapper = new LMGQueryMapper();

	/**
	 * Returns the query string for select statement.
	 * 
	 * @return String
	 */
	public static String exportQuery() throws SQLException {

		String tstQuery = "";
		List<String> columnList = new ArrayList<String>();
		List<String> tableList = new ArrayList<String>();
		List<String> headerList = new ArrayList<String>();
		List<String> joinList = new ArrayList<String>();
		try {

			Properties prop = new Properties();
			prop.load(new FileInputStream(
					LMGImportExportUtilityIfc.LMGImportExport_properties));
			
			DocumentBuilder db = documentBuilderFactory.newDocumentBuilder();
			file = new File(
					prop
							.getProperty(LMGImportExportUtilityIfc.LMGImportExport_EXPORTXML));
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			NodeList nodeLst = doc.getElementsByTagName("elements");
			for (int s = 0; s < nodeLst.getLength(); s++) {
				String elementsName = nodeLst.item(s).getFirstChild()
						.getNodeValue();
				headerList.add(elementsName);
			}

			//config.setFileHeader(headerList);
			LMGExportConfig.setFileHeader(headerList);

			String queryType = "";
			NodeList queryTypeList = doc.getElementsByTagName("query");
			for (int p1 = 0; p1 < queryTypeList.getLength(); p1++) {
				queryType = queryTypeList.item(p1).getAttributes()
						.getNamedItem("sqlquery").getNodeValue();

				if (queryType.equalsIgnoreCase("false")) {
					NodeList tbleLst = doc.getElementsByTagName("table");
					for (int s = 0; s < tbleLst.getLength(); s++) {
						String tableName = tbleLst.item(s).getAttributes()
								.getNamedItem("name").getNodeValue();
						tableList.add(tableName);
						mapper.setTableName(tableList);
						NodeList clmnLst = doc
								.getElementsByTagName("columnname");

						for (int i = 0; i < clmnLst.getLength(); i++) {
							String columnName = clmnLst.item(i).getFirstChild()
									.getNodeValue();
							if (!columnList.contains(columnName)) {
								columnList.add(columnName);
							}
						}
						mapper.setColumnNames(columnList);
					}

					// ADDED FOR JOIN
					String assosiationType = "";
					NodeList assosiationsTypeList = doc
							.getElementsByTagName("associations");
					NodeList assosiationTypeList = doc
							.getElementsByTagName("association");
					for (int p = 0; p <= assosiationsTypeList.getLength(); p++) {
						assosiationType = assosiationTypeList.item(p)
								.getAttributes().getNamedItem("type")
								.getNodeValue();

						if (assosiationType.equalsIgnoreCase("CLOSE")) {
							NodeList joinLst = doc.getElementsByTagName("JOIN");
							for (int k = 0; k < joinLst.getLength(); k++) {
								Node fstNode = joinLst.item(k);
								String leftcontion = "";
								String rightcontion = "";
								String joinCondition = "";

								Element fstElmnt = (Element) fstNode;
								NodeList fsttblElmntLst = fstElmnt
										.getElementsByTagName("tablename");
								NodeList fstclmElmntLst = fstElmnt
										.getElementsByTagName("colname");
								NodeList jyntblElmntLst = fstElmnt
										.getElementsByTagName("jointablename");
								NodeList jynclmElmntLst = fstElmnt
										.getElementsByTagName("joincolname");

								Element fstNmElmnt = (Element) fsttblElmntLst
										.item(0);
								Element fstclmElmnt = (Element) fstclmElmntLst
										.item(0);
								Element jynNmElmnt = (Element) jyntblElmntLst
										.item(0);
								Element jynclmElmnt = (Element) jynclmElmntLst
										.item(0);

								NodeList fstNm = fstNmElmnt.getChildNodes();
								NodeList fstclm = fstclmElmnt.getChildNodes();
								NodeList jynNm = jynNmElmnt.getChildNodes();
								NodeList jynclm = jynclmElmnt.getChildNodes();

								leftcontion = ((Node) fstNm.item(0))
										.getNodeValue()
										+ "."
										+ ((Node) fstclm.item(0))
												.getNodeValue();
								rightcontion = ((Node) jynNm.item(0))
										.getNodeValue()
										+ "."
										+ ((Node) jynclm.item(0))
												.getNodeValue();
								joinCondition = leftcontion + " = "
										+ rightcontion;

								joinList.add(joinCondition);

							}
						}
						if (assosiationType.equalsIgnoreCase("OPEN")) {
							NodeList opnjoinLst = doc
									.getElementsByTagName("openjoin");
							for (int q = 0; q < opnjoinLst.getLength(); q++) {
								Node openfstNode = opnjoinLst.item(q);
								String openleftcontion = "";
								String openrightcontion = "";
								String openjoinCondition = "";
								String openoperator = "";

								Element openfstElmnt = (Element) openfstNode;
								NodeList openfsttblElmntLst = openfstElmnt
										.getElementsByTagName("openjointablename");
								NodeList openfstclmElmntLst = openfstElmnt
										.getElementsByTagName("openjoincolumnname");
								NodeList openoperatorLst = openfstElmnt
										.getElementsByTagName("operator");
								NodeList openjoinelmLst = openfstElmnt
										.getElementsByTagName("openjoinvalue");

								Element openfstNmElmnt = (Element) openfsttblElmntLst
										.item(0);
								Element openfstclmElmnt = (Element) openfstclmElmntLst
										.item(0);
								Element openoperatorElmt = (Element) openoperatorLst
										.item(0);
								Element openjynvalueElmnt = (Element) openjoinelmLst
										.item(0);

								NodeList openfstNm = openfstNmElmnt
										.getChildNodes();
								NodeList openfstclm = openfstclmElmnt
										.getChildNodes();
								NodeList openoperterclm = openoperatorElmt
										.getChildNodes();
								NodeList openjoinvalue = openjynvalueElmnt
										.getChildNodes();

								openleftcontion = ((Node) openfstNm.item(0))
										.getNodeValue()
										+ "."
										+ ((Node) openfstclm.item(0))
												.getNodeValue();
								openoperator = ((Node) openoperterclm.item(0))
										.getNodeValue();
								openrightcontion = ((Node) openjoinvalue
										.item(0)).getNodeValue();

								openjoinCondition = openleftcontion + " "
										+ openoperator + " '"
										+ openrightcontion + "'";
								joinList.add(openjoinCondition);

							}
						}

					}

					// ADDED FOR BATCH UPDATE
					mapper.setJoinList(joinList);

					LMGExportConfig.getQueryMapper().add(mapper);
					tstQuery = LMGExportQueryWriter.getQuery();
					
				} else {
					NodeList sqlLst = doc.getElementsByTagName("sql");
					tstQuery = sqlLst.item(0).getFirstChild().getNodeValue();
				}
			}
		} catch (Exception e) {
			log.info(e.getMessage());
		}
		return tstQuery;
	}

	/**
	 * 
	 * Returns the query string for update statement.
	 * 
	 * @return String
	 */	 
	public static String updateQuery() {
		List<String> batchtableList = new ArrayList<String>();
		String updateQuery = "";
		DocumentBuilder db;
		try {
			db = documentBuilderFactory.newDocumentBuilder();
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			NodeList btchuplst = doc.getElementsByTagName("BatchUpdate");
			for (int h = 0; h < btchuplst.getLength(); h++) {
				NodeList btchtbllst = doc.getElementsByTagName("Table");
				for (int j = 0; j < btchtbllst.getLength(); j++) {
					String batchTableName = btchtbllst.item(j).getAttributes()
							.getNamedItem("name").getNodeValue();
					String batchTableclm = btchtbllst.item(j).getAttributes()
							.getNamedItem("column").getNodeValue();
					String batchTablevalue = btchtbllst.item(j).getAttributes()
							.getNamedItem("value").getNodeValue();
					String batchWhereClause = btchtbllst.item(j)
							.getAttributes().getNamedItem("whereselectcolumn")
							.getNodeValue();
					
					batchtableList.add(batchTableName);
					batchtableList.add(batchTableclm);
					batchtableList.add(batchTablevalue);
					batchtableList.add(batchWhereClause);
				}
			}
			mapper.setBatchupdateList(batchtableList);
			LMGExportConfig.getQueryMapper().add(mapper);
			updateQuery = LMGExportQueryWriter.updateSQLQuery();
		} catch (ParserConfigurationException e) {
			log.info(e.getMessage());
		} catch (IOException e) {
			log.info(e.getMessage());
		} catch (Exception e) {
			log.info(e.getMessage());
		}
		return updateQuery;
	}

}