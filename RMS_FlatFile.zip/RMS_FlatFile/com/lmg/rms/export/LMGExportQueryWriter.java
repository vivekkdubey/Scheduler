/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * This class is used to create query for select statement
 * and for update statement.
 *  
 * @author Ashutosh Mani
 *
 */
public class LMGExportQueryWriter {
	
	private static Logger log = Logger.getLogger(LMGExportQueryWriter.class);
	@SuppressWarnings("unchecked")
	static String whereUpdateClause = "";
	static String fromUpdateClause = "";

	/**
	 * Returns the query string for select statement.
	 * 
	 * @return String
	 */
	public static String getQuery() {
		List<LMGQueryMapper> qList = new ArrayList<LMGQueryMapper>();
		List<String> tablenameList = new ArrayList<String>();
		List<String> clmnList = new ArrayList<String>();
		List<String> jList = new ArrayList<String>();

		LMGQueryMapper mpr = new LMGQueryMapper();
		String columnStr = "";
		String totalColumnStr = "";
		String tableStr = "";
		String totalTableStr = "";
		String joinStr = "";
		String totaljoinStr = "";

		qList = LMGExportConfig.getQueryMapper();
		for (int k = 0; k < qList.size(); k++) {

			mpr = (LMGQueryMapper) qList.get(k);
			tablenameList = mpr.getTableName();
			for (int k1 = 0; k1 < tablenameList.size(); k1++) {
				tableStr = tablenameList.get(k1).toString();
				if (!totalTableStr.contains(tableStr)) {
					if (!totalTableStr.equals("")) {
						totalTableStr = totalTableStr + tableStr + ",";
					} else {
						totalTableStr = tableStr + ",";
					}
				}
			}
			if (totalTableStr.endsWith(",")) {
				int lasttableIdx = totalTableStr.length() - 1;
				totalTableStr = totalTableStr.substring(0, lasttableIdx);
			}

			clmnList = mpr.getColumnNames();
			for (int m = 0; m < clmnList.size(); m++) {
				columnStr = clmnList.get(m).toString();

				if (!totalColumnStr.contains(columnStr)) {
					if (!totalColumnStr.equals("")) {
						totalColumnStr = totalColumnStr + columnStr + ",";
					} else {
						totalColumnStr = columnStr + ",";
					}
				}
			}
			if (totalColumnStr.endsWith(",")) {
				int lastIdx = totalColumnStr.length() - 1;
				totalColumnStr = totalColumnStr.substring(0, lastIdx);
			}

			jList = mpr.getJoinList();
			for (int n = 0; n < jList.size(); n++) {
				joinStr = jList.get(n).toString();
				if (!totaljoinStr.contains(joinStr)) {
					if (!totaljoinStr.equals("")) {
						totaljoinStr = totaljoinStr + joinStr + " and ";
					} else {
						totaljoinStr = joinStr + " and ";
					}
				}
			}
			if (totaljoinStr.endsWith("and ")) {
				int lastjoinIdx = totaljoinStr.length() - 4;
				totaljoinStr = totaljoinStr.substring(0, lastjoinIdx);
			}
		}
		fromUpdateClause = totalTableStr;
		whereUpdateClause = totaljoinStr;
		String Select_SQL = "SELECT " + totalColumnStr + " FROM "
				+ totalTableStr + " where " + totaljoinStr;
		String q2 ="and TR_LTM_SLS_RTN.ID_STR_RT in(select id_str_rt from CO_STR_LST where ID_ENB_COD =1 and ID_STR_STS=1)";
		Select_SQL = Select_SQL + q2;

		log.info(Select_SQL);
		return Select_SQL;
	}

	/**
	 * Returns the query string for update statement.
	 * 
	 * @return String
	 */
	public static String updateSQLQuery() {
		List<String> bUList = new ArrayList<String>();
		List updateQList = new ArrayList();
		LMGQueryMapper updatempr = new LMGQueryMapper();
		String Update_SQL = "";
		String btchupStrtable = "";
		String btchupStrcolumn = "";
		String btchupStrvalue = "";
		String btchupSelvalue = "";
		updateQList = LMGExportConfig.getQueryMapper();

		for (int p = 0; p < updateQList.size(); p++) {

			if (!updateQList.contains(updatempr)) {
				updatempr = (LMGQueryMapper) updateQList.get(p);
				bUList = updatempr.getBatchupdateList();
				btchupStrtable = bUList.get(0).toString();
				btchupStrcolumn = bUList.get(1).toString();
				btchupStrvalue = bUList.get(2).toString();
				btchupSelvalue = bUList.get(3).toString();

				String q2 ="and TR_LTM_SLS_RTN.ID_STR_RT in(select id_str_rt from CO_STR_LST where ID_ENB_COD =1 and ID_STR_STS=1)";
				Update_SQL = "Update " + btchupStrtable + " set "
						+ btchupStrcolumn + " = " + btchupStrvalue + " where "
						+ btchupSelvalue + " in ( SELECT " + btchupSelvalue
						+ " from " + fromUpdateClause + " where "
						+ whereUpdateClause +  q2 + " ) ";
			}
		}
		log.info(Update_SQL);
		return Update_SQL;
	}
}
