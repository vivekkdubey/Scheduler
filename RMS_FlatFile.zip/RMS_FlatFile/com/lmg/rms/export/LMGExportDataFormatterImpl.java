/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.sql.ResultSet;

/**
 * This class is not used right now, may be used in further 
 * implementation.
 * 
 * @author Ashutosh Mani
 *
 */
public class LMGExportDataFormatterImpl implements LMGExportDataFormatter {

	public void formatExportData(ResultSet resultSet) {
		try {
			//LMGExportParser.createLMGExportXml(resultSet);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}

	}
}
