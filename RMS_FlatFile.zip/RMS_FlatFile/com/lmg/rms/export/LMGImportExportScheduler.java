/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright (c) 2011 LandMark Group.    All Rights Reserved.
 *
 *  Rev 1.0   Mar 18 2011 Ashutosh.Tripathi 
 *  This file is using the scheduledExecutorService interface 
 *  which extends ExecutorService class provided in java5 in java.util.concurrent package 
 *  to schedule tasks with various delays and return a task object that can be used to 
 *  cancel or check execution. The �scheduleAtFixedRate()�  methods create and execute 
 *  tasks that run periodically until cancelled.
 *  This Class will create two threads one will invoke the flat file export mechanism 
 *  and the other one will be invoking the flat file import mechanism. 
 *  The delay time for flat file writing and reading could be different 
 *  and configurable according to the need.
 *  The Scheduler will call the process() method to get the instance of LMGExportProcessor.
 *  
 *  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * This file is using the scheduledExecutorService interface 
 *  which extends ExecutorService class provided in java5 in java.util.concurrent package 
 *  to schedule tasks with various delays and return a task object that can be used to 
 *  cancel or check execution. The �scheduleAtFixedRate()�  methods create and execute 
 *  tasks that run periodically until cancelled.
 *  
 * @author Ashutosh.Tripathi
 *
 */
public class LMGImportExportScheduler {
	
	private static Logger log = Logger.getLogger(LMGImportExportScheduler.class);
	
	public static void main(String[] args) {
		try{
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(LMGImportExportUtilityIfc.LMGImportExport_properties);
		prop.load(fis);
		
		String filePath = prop.getProperty(LMGImportExportUtilityIfc.LMGImportExport_LOG4JPROPERTIES);
		PropertyConfigurator.configure(filePath + "log4j.properties"); 
		encryptDecryptProperties();
		scheduleExportFlatFile();
		fis.close();
		}	
		catch(Exception e){
			log.info(e.getMessage());
		}
	}

	/*final static ScheduledExecutorService scheduler = Executors
			.newScheduledThreadPool(5);
*/
	/**
	 * This method is used to schedule the exportation
	 * of flat file.
	 */
	public static void scheduleExportFlatFile() {
		
					LMGExportFactory.getExportProcessor().process();
				
	}
	
	/**
	 * This method is used to update the DBURL, Usename, Password 
	 *  in the properties file.
	 */
	private static void encryptDecryptProperties()
	{
		updateDBURL();
		updateDBUserName();
		updateDBPassword();
		
	}
		
	/**
	 * This method is used to update the encrypted/decrepted  DBURL 
	 *  in the properties file.
	 */
	private static void updateDBURL(){
		PropertyReader propReader = new PropertyReader();
		Properties prp = new Properties();
		
		String userURLInput = "";
		
		try{
			FileInputStream fis = new FileInputStream(LMGImportExportUtilityIfc.LMGImportExport_properties);
			prp.load(fis);
			userURLInput = EncryptDecrypt.decryptText(prp.getProperty(LMGImportExportUtilityIfc.LMGImportExportProperties_DBURL));
			if(userURLInput==null || userURLInput.trim().equals("")){
				userURLInput=prp.getProperty(LMGImportExportUtilityIfc.LMGImportExportProperties_DBURL);
			}
			fis.close();
		}catch(Exception e)
		{
			log.info(e.getMessage());
		}
		
		propReader.updateProperties(LMGImportExportUtilityIfc.LMGImportExportProperties_DBURL, EncryptDecrypt.encryptText(userURLInput),LMGImportExportUtilityIfc.LMGImportExport_properties );
	}
	
	/**
	 * This method is used to update the encrypted/decrepted username 
	 *  in the properties file.
	 */
	private static void updateDBUserName(){
		PropertyReader propReader = new PropertyReader();
		Properties prp = new Properties();
		
		String userNameInput = "";
		
		try{
			FileInputStream fis = new FileInputStream(LMGImportExportUtilityIfc.LMGImportExport_properties);
			prp.load(fis);
			userNameInput = EncryptDecrypt.decryptText(prp.getProperty(LMGImportExportUtilityIfc.LMGImportExport_DBUSER));
			if(userNameInput==null || userNameInput.trim().equals("")){
				userNameInput=prp.getProperty(LMGImportExportUtilityIfc.LMGImportExport_DBUSER);
			}
			fis.close();
		}catch(Exception e)
		{
			log.info(e.getMessage());
		}
		
		propReader.updateProperties(LMGImportExportUtilityIfc.LMGImportExport_DBUSER, EncryptDecrypt.encryptText(userNameInput),LMGImportExportUtilityIfc.LMGImportExport_properties );
	}
	
	/**
	 * This method is used to update the encrypted/decrepted password 
	 *  in the properties file.
	 */
	private static void updateDBPassword(){
		PropertyReader propReader = new PropertyReader();
		Properties prp = new Properties();
		
		String userPasswordInput = "";
		
		try{
			FileInputStream fis = new FileInputStream(LMGImportExportUtilityIfc.LMGImportExport_properties);
			prp.load(fis);
			userPasswordInput = EncryptDecrypt.decryptText(prp.getProperty(LMGImportExportUtilityIfc.LMGImportExport_DBPASSWORD));
			if(userPasswordInput==null || userPasswordInput.trim().equals("")){
				userPasswordInput=prp.getProperty(LMGImportExportUtilityIfc.LMGImportExport_DBPASSWORD);
			}
			fis.close();
		}catch(Exception e)
		{
			log.info(e.getMessage());
		}
		
		propReader.updateProperties(LMGImportExportUtilityIfc.LMGImportExport_DBPASSWORD, EncryptDecrypt.encryptText(userPasswordInput),LMGImportExportUtilityIfc.LMGImportExport_properties );
	}
	
}
