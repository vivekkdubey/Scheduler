/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright (c) 2011 LandMark Group.    All Rights Reserved.
 *
 *  Rev 1.0   Mar 18 2011 Ashutosh Tripathi 
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
package com.lmg.rms.export;

/**
 * This is a constant file which holds all the constants
 * related to export flat file.
 * 
 * @author ashutosh.tripathi
 * 
 */
public interface LMGImportExportUtilityIfc {
	
	public static final String LMGImportExport_properties = "D:/LMG/CO_Workspace/RMS_FlatFile/com/lmg/rms/export/lmgimportexport.properties";

	public static final String LMGImportExportProperties_DBURL = "db_url";

	public static final String LMGImportExport_JDBCDRIVETR = "jdbc_driver";

	public static final String LMGImportExport_DBUSER = "db_userid";

	public static final String LMGImportExport_DBPASSWORD = "db_password";

	public static final String LMGImportExport_OUTPUTFILENAME = "output_file";

	public static final String LMGImportExport_DBQUERY = "sql_query";

	public static final String LMGImportExport_EXPPROCESSOR = "exportProcessor";

	public static final String LMGImportExport_EXPDATAPROCESSOR = "exportDataProcessor";

	public static final String LMGImportExport_EXPDATAFORMATTER = "exportDataFormatter";

	public static final String LMGImportExport_EXPFILEWRITER = "exportFileWriter";

	public static final String LMGImportExport_DELAYTIME_SECONDS = "exportDelayTime";

	public static final String LMGImportExport_PERIODTIME_SECONDS = "exportPeriodTime";

	public static final String LMGImportExport_EXPORTDURATION_SECONDS = "exportDuration";
	
	public static final String LMGImportExport_IMPORTDELAYTIME_SECONDS = "importDelayTime";

	public static final String LMGImportExport_IMPORTPERIODTIME_SECONDS = "importPeriodTime";

	public static final String LMGImportExport_IMPORTDURATION_SECONDS = "importDuration";
	
	public static final String LMGImportExport_IMPDATAFORMATTER = "importDataFormatter";

	public static final String LMGImportExport_IMPDATAPROCESSOR = "importDataProcessor";

	public static final String LMGImportExport_IMPPROCESSOR = "importProcessor";

	public static final String LMGImportExport_IMPFILEREADER = "importFileReader";
	
	public static final String LMGImportExport_SRC_DIR = "exportFileDirPath";
	
	public static final String LMGImportExport_IMPFILETRNASFERLOCATION = "importFileTrnaferLocation";

	public static final String LMGImportExport_IMPORTXML = "importXML";
	
	public static final String LMGImportExport_EXPORTXML = "exportXML";
	
	public static final String LMGImportExport_NULLCHKTABLEVAR = "nullchkTableVar";
	
	public static final String LMGImportExport_LOG4JPROPERTIES = "flatfileroot";
	
	public static String ENCRYPTION_DECRYPTION_KEY = "lSiPlEnCdEcKeY";
}
