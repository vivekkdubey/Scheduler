/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright (c) 2011 LandMark Group.    All Rights Reserved.
 *
 *  Rev 1.0   Mar 18 2011 Ashutosh.Tripathi 
 *  
 *  This Interface will contain only method declaration.
 *  In the implementation of this method we will format the result
 *  of the query triggered in the implementation the method declared in this file.  
 *  So that we can save the data in the flat file in a specified manner, later which will be sent to DMS
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.sql.ResultSet;

/**
 * This interface is not used right now, may be used in further 
 * implementation.
 * 
 * 
 * @author ashutosh.tripathi
 * 
 */
public interface LMGExportDataFormatter {
	void formatExportData(ResultSet resultSet);
}
