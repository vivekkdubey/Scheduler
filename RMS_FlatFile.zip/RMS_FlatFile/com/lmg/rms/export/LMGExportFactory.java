/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright (c) 2011 LandMark Group.    All Rights Reserved.
 *
 *  Rev 1.0   Mar 18 2011 Ashutosh.Tripathi
 *
 *  This is a Factory class which is responsible for creating an Object.
 *  This class is responsible for instantiating the appropriate Subclass
 *  by creating the right Object of the related classes.
 *  This promotes loose coupling by eliminating the need to bind application-specific
 *  classes into the code. This class is using the properties file and it utility class
 *  to get the instantiation done.
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * This factory class is used to get the instances
 * of different type of classes.
 * 
 * @author ashutosh.tripathi
 *
 */
public class LMGExportFactory {
	private static Logger log = Logger.getLogger(LMGExportFactory.class);
	private static LMGExportProcessor expProcessor = null;
	private static LMGExportDataProcessor expDataProcessor = null;
	private static LMGExportDataFormatter expDataFormatter = null;
	private static LMGExportFileWriter expFileWriter = null;

	static Properties prop = new Properties();

	/**
	 * Return instance of LMGExportProcessor
	 * 
	 * @return LMGExportProcessor
	 */
	public static LMGExportProcessor getExportProcessor() {

		if (expProcessor == null) {
			try {
				prop.load(new FileInputStream(
						LMGImportExportUtilityIfc.LMGImportExport_properties));
				String exportProcessorString = prop
						.getProperty(LMGImportExportUtilityIfc.LMGImportExport_EXPPROCESSOR);
				Class exportProcessor = Class.forName(exportProcessorString);
				expProcessor = (LMGExportProcessor) exportProcessor.newInstance();
			} catch (ClassNotFoundException e) {
				log.info(e.getMessage());
			} catch (InstantiationException e) {
				log.info(e.getMessage());
			} catch (IllegalAccessException e) {
				log.info(e.getMessage());
			} catch (FileNotFoundException e) {
				log.info(e.getMessage());
			} catch (IOException e) {
				log.info(e.getMessage());
			}
		}

		return expProcessor;
	}

	/**
	 * Return instance of LMGExportDataProcessor
	 * 
	 * @return LMGExportDataProcessor
	 */
	public static LMGExportDataProcessor getExportDataProcessor() {
		if (expDataProcessor == null) {
			try {
				prop.load(new FileInputStream(
						LMGImportExportUtilityIfc.LMGImportExport_properties));
				String exportDataProcessorString = prop
						.getProperty(LMGImportExportUtilityIfc.LMGImportExport_EXPDATAPROCESSOR);
				Class exportDataProcessor = Class.forName(exportDataProcessorString);
				expDataProcessor = (LMGExportDataProcessor) exportDataProcessor
						.newInstance();
			} catch (ClassNotFoundException e) {
				log.info(e.getMessage());
			} catch (InstantiationException e) {
				log.info(e.getMessage());
			} catch (IllegalAccessException e) {
				log.info(e.getMessage());
			} catch (FileNotFoundException e) {
				log.info(e.getMessage());
			} catch (IOException e) {
				log.info(e.getMessage());
			}
		}
		return expDataProcessor;
	}

	/**
	 * Return instance of LMGExportDataFormatter
	 * 
	 * @return LMGExportDataFormatter
	 */
	public static LMGExportDataFormatter queryExportFormatter() {
		if (expDataFormatter == null) {
			try {
				prop.load(new FileInputStream(
						LMGImportExportUtilityIfc.LMGImportExport_properties));
				String exportDataFormatterString = prop
						.getProperty(LMGImportExportUtilityIfc.LMGImportExport_EXPDATAFORMATTER);
				Class exportDataFormatter = Class.forName(exportDataFormatterString);
				expDataFormatter = (LMGExportDataFormatter) exportDataFormatter
						.newInstance();
			} catch (ClassNotFoundException e) {
				log.info(e.getMessage());
			} catch (InstantiationException e) {
				log.info(e.getMessage());
			} catch (IllegalAccessException e) {
				log.info(e.getMessage());
			} catch (FileNotFoundException e) {
				log.info(e.getMessage());
			} catch (IOException e) {
				log.info(e.getMessage());
			}
		}

		return expDataFormatter;
	}

	/**
	 * Return instance of LMGExportFileWriter
	 * 
	 * @return LMGExportFileWriter
	 */
	public static LMGExportFileWriter getExpWriter() {
		if (expFileWriter == null) {
			try {
				prop.load(new FileInputStream(
						LMGImportExportUtilityIfc.LMGImportExport_properties));
				String exportFileWriterString = prop
						.getProperty(LMGImportExportUtilityIfc.LMGImportExport_EXPFILEWRITER);
				Class exportFileWriter = Class.forName(exportFileWriterString);
				expFileWriter = (LMGExportFileWriter) exportFileWriter.newInstance();
			} catch (ClassNotFoundException e) {
				log.info(e.getMessage());
			} catch (InstantiationException e) {
				log.info(e.getMessage());
			} catch (IllegalAccessException e) {
				log.info(e.getMessage());
			} catch (FileNotFoundException e) {
				log.info(e.getMessage());
			} catch (IOException e) {
				log.info(e.getMessage());
			}
		}

		return expFileWriter;
	}


}
