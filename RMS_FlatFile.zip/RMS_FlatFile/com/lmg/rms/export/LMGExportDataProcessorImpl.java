/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

/**
 * This class is used to run the SQL query and get the resultset.
 * 
 * 
 * @author Ashutosh Mani
 *
 */
public class LMGExportDataProcessorImpl implements LMGExportDataProcessor {
	
	private static Logger log = Logger.getLogger(LMGExportDataProcessorImpl.class);
	
	/**
	 * This class is used to run the SQL query and returns the resultset.
	 * 
	 * @returns ResultSet
	 */
	public ResultSet queryExportData(Connection con, Statement stmt,
			ResultSet resultSet) {

		Connection con1 = null;
		Statement stmt1 = null;		

		try {

			con = LMGDataSourceFactory.getDBConnection();
			con1 = LMGDataSourceFactory.getDBConnection();
			stmt = con.createStatement();
			stmt1 = con1.createStatement();
			
			resultSet=stmt.executeQuery(LMGExportParser.exportQuery());
			stmt1.executeUpdate(LMGExportParser.updateQuery());
		} catch (SQLException e) {
			log.info(e.getMessage());			
		}
		
		return resultSet;
	}
}
