/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;

/**
 * This class is used to get the instance of database  connection.
 * 
 * @author ashutosh.tripathi
 * 
 */
public class LMGDataSourceFactory {
	private static Logger log = Logger.getLogger(LMGDataSourceFactory.class);
	private static Connection connection;

	/**
	 *  Returns the instance of database  connection.
	 *  
	 * @return Connection
	 */
	public static Connection getDBConnection() {
		try {
			Properties prop = new Properties();
			prop.load(new FileInputStream(
					LMGImportExportUtilityIfc.LMGImportExport_properties));
			String db_url = EncryptDecrypt.decryptText(prop
					.getProperty(LMGImportExportUtilityIfc.LMGImportExportProperties_DBURL));
			String db_userid = EncryptDecrypt.decryptText(prop
					.getProperty(LMGImportExportUtilityIfc.LMGImportExport_DBUSER));
			String db_password = EncryptDecrypt.decryptText(prop
					.getProperty(LMGImportExportUtilityIfc.LMGImportExport_DBPASSWORD));
			String jdbc_driver = prop
					.getProperty(LMGImportExportUtilityIfc.LMGImportExport_JDBCDRIVETR);

			BasicDataSource basicDataSource = new BasicDataSource();
			basicDataSource.setDriverClassName(jdbc_driver);
			basicDataSource.setUrl(db_url);
			basicDataSource.setUsername(db_userid);
			basicDataSource.setPassword(db_password);
			connection = basicDataSource.getConnection();
		} catch (FileNotFoundException fnf) {
			log.info(fnf.getMessage());
		} catch (SQLException sqle) {
			log.info(sqle.getMessage());
		} catch (IOException ioe) {
			log.info(ioe.getMessage());
		} catch (Exception e) {
			log.info(e.getMessage());
		}
		return connection;
	}
}
