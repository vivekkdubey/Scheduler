/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.util.ArrayList;
import java.util.List;

/**
 * This class provides setter getter for fileHeader and queryMapper.
 * 
 * @author Ashutosh Mani
 *
 */
public class LMGExportConfig {

	private static List fileHeader = new ArrayList(0);
	private static List queryMapper = new ArrayList(0);
	

	public static List getFileHeader() {
		return fileHeader;
	}
	
	public static void setFileHeader(List fileHeader) {
		LMGExportConfig.fileHeader = fileHeader;
	}
	
	public static List getQueryMapper() {
		return queryMapper;
	}
	
	public void setQueryMapper(List queryMapper) {
		LMGExportConfig.queryMapper = queryMapper;
	}
	
}
