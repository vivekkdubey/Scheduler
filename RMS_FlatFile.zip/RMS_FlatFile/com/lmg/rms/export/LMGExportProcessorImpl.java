/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.io.Writer;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;

/**
 * This class is the implementation class for the Export Processing.
 * 
 * @author Ashutosh Mani
 *
 */
public class LMGExportProcessorImpl implements LMGExportProcessor {
	private static Logger log = Logger.getLogger(LMGExportProcessorImpl.class);
	public static Connection con;
	public static Statement stmt;
	public static ResultSet resultSet;
	public static Writer out;
	
	/**
	 * This method is used to get data from data base and
	 * create the flat file.
	 * 
	 */
	public void process() {
		try{
			resultSet = LMGExportFactory.getExportDataProcessor().queryExportData(
					con, stmt, resultSet);
			LMGExportFactory.queryExportFormatter().formatExportData(resultSet);
			LMGExportFactory.getExpWriter().createFlatFile(resultSet, out);
		}catch(Exception e){
			log.info(e.getMessage());
		}
	}

}
