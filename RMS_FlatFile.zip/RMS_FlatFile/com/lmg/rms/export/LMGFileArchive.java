/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Properties;

public class LMGFileArchive {
			
	public static void archiveFlatFile(){
	 {
		try {
			//1
			Properties prop = new Properties();
			prop.load(new FileInputStream(LMGImportExportUtilityIfc.LMGImportExport_properties));
			String dirLocation = prop.getProperty(LMGImportExportUtilityIfc.LMGImportExport_SRC_DIR);
			File dir = new File(dirLocation);
			
			//while dir has files , list all ..filter files , list move move
			
			//file.isDirectory();

			FilenameFilter ff = new FilenameFilter() {
				
				public boolean accept(File dir, String name) {
					// TODO Auto-generated method stub
					return name.startsWith("export_batchid_"); 

				}
			};  

			String[] allFilesWith_txt = dir.list(ff);
			
			//create absolute file name dir name + File.Seperator + each file
		
		 for(int i=0; i<allFilesWith_txt.length; i++)
		 {
			 String filestr = dirLocation+allFilesWith_txt[i];
			 File fileName =  new File(filestr);
			 fileName.renameTo (new File(prop.getProperty(LMGImportExportUtilityIfc.LMGImportExport_IMPFILETRNASFERLOCATION),fileName.getName())); 
		 }
			
			/**
			 * BELOW THERE IS A ARCHIVING OF THE FILES ONCE IT GETS READ
			 * 
			 */
			
		
		}catch (FileNotFoundException FNF) {// Catch exception if any
			System.err.println("Error: " + FNF.getMessage());
		}catch (IOException IOE) {// Catch exception if any
				System.err.println("Error: " + IOE.getMessage());
		}catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

}
}





