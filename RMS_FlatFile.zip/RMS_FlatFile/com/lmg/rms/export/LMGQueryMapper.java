/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *     Copyright (c) 2010 LandMark Group.    All Rights Reserved.
 * 		
 * Rev 1.0  July 05, 2011 10:15:31 AM Ashutosh Mani
 * Initial revision.
 * Resolution for LMG-POS-CD Creation-FES v 0 1.doc
 * Added for Customer DElvery Requirement 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.lmg.rms.export;

import java.util.ArrayList;
import java.util.List;

/**
 * This class works as query manager which have setter getters
 * for tableNames, columnNames etc.
 * 
 * @author Ashutosh Mani
 *
 */
public class LMGQueryMapper {
	private List tableName = new ArrayList(0);
	private List columnNames = new ArrayList(0);	
	private List joinList = new ArrayList(0);	
	private List batchupdateList = new ArrayList(0);
	
	public List getBatchupdateList() {
		return batchupdateList;
	}
	
	public void setBatchupdateList(List batchupdateList) {
		this.batchupdateList = batchupdateList;
	}
	
	public List getJoinList() {
		return joinList;
	}
	
	public void setJoinList(List joinList) {
		this.joinList = joinList;
	}
	
	public List getTableName() {
		return tableName;
	}
	
	public void setTableName(List tableName) {
		this.tableName = tableName;
	}
	
	public List getColumnNames() {
		return columnNames;
	}
	
	public void setColumnNames(List columnNames) {
		this.columnNames = columnNames;
	}
	
}
